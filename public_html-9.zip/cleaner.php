<?php

foreach(glob('uploads/*') as $file)
{
 if(is_file($file)) unlink($file);
}

foreach(glob('json/*') as $file)
{
 if(is_file($file)) unlink($file);
}

header("Location: index.html")
?>