const image = document.getElementById("image");
const cleaner = document.getElementById("cleaner");
const inpFile = document.getElementById("inpFile");
const endpoint = "upload.php";
const endpoint2 = "uploadJSON.php";

let name;
console.log("onload " + name)

document.querySelectorAll(".drop-zone__input").forEach(inputElement => {
	const spot = inputElement.closest(".drop-zone");
	spot.addEventListener("dragover", e => {
		e.preventDefault();
	});

	spot.addEventListener("drop", e => {
		e.preventDefault();
		console.log('drop')

		if (e.dataTransfer.files.length) {
			inputElement.files = e.dataTransfer.files;
			upload(spot, e.dataTransfer.files[0]);
		};
	});
});

function upload(spot, file) {
        console.log("upload")
        cleaner.submit();

		const formData = new FormData();
		
		formData.append("inpFile", inpFile.files[0]);
		fetch(endpoint, {
			method: "post",
			body: formData
		})
		.catch(console.error);
}
//"json/data.json" https://reqres.in/api/users
fetch('json/data.json', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify({
        name: 'Ann'
    })
}).then(res => {
    return res.json()
})
.then(data => console.log(data))
.catch(console.error);




/*
function getName() {
    fetch('uploadsData.json')
        .then(res => res.json())
        .then(data => {
            console.log(data);
            name = data.name;
            console.log(name);
            image.src="uploads/" + name;
            console.log(image.src)
        });
}
getName()


function tracker() {
        fetch('http://lllexxx673.temp.swtest.ru/uploads/image.jpg')
        .then(res => res.blob())
        .then(blob => {
            const newSize = blob.size
            console.log("new size " + newSize)
            if(newSize !== size){
            console.log("changed")
            location.reload()
            }
        })
}

//setInterval(() => tracker(), 1000);
*/