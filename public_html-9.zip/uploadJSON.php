<?php
/*
if (isset($_POST)) {
    $file = $_FILES['jsonData'];
    print_r($file);
    //$fileName = $_FILES['jsonData'];
}
*/

$targetPath = "json/" . basename($_FILES["jsonData"]);
move_uploaded_file($_FILES["jsonData"], $targetPath);